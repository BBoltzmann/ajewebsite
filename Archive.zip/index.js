const hamburger = document.getElementById('hamburger');
const navbar = document.getElementById('navbar');
const storeIcon = document.getElementById('storeIcon');

hamburger.addEventListener('click', () => {


})

function show() {
    document.getElementById('navbar1').style.display = 'flex';
}